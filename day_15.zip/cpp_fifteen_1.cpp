#include<fstream>
#include<iostream>
using namespace std;

int main()
{
	fstream myfile;
	myfile.open("file5.txt",ios::in);
	
	if(!myfile)
		cout<<"the file cannot open"<<endl;
		
		
	return 0;
}
