#include<fstream>
#include<iostream>
using namespace std;

int main()
{	
	fstream fin,fout;
	fin.open("hello.txt");
	fout.open("hello123.txt");
	char ch;
	while(!fin.eof())
	{
		fin.get(ch);
		fout<<ch;
	}
	cout<<"copy done!"<<endl;
	fin.close();
	fout.close();
	
	
	return 0;
}
