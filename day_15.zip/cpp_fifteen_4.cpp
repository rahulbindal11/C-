#include<fstream>
#include<iostream>
using namespace std;

int main()
{	
	fstream fin;
	//fstream input; string str,str2;
	fin.open("hello.txt");
	int count=0;
	char word[30];
	if(!fin)
		cout<<"file did not open"<<endl;
	else{
	while(!fin.eof())
	{
	fin>>word;
	count++;
	//input>>str>>str2;
	//cout<<str<<'\t'<<str2<<endl;
	
	}
	cout<<"total words:"<<count<<endl;
	
	}
		fin.close();
		//input.close();
		
	return 0;
}
